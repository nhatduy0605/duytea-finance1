// Utility functions

export const fmt = (n) => {
  if (!n && n !== 0) return '0'
  const abs = Math.abs(n)
  if (abs >= 1000) return (n / 1000).toFixed(1) + ' ty'
  if (abs >= 1)    return Number(n).toFixed(1) + 'tr'
  return Math.round(n * 1000) + 'k'
}

export const pct = (a, b) => (b > 0 ? Math.min(100, Math.round((a / b) * 100)) : 0)

export const today = () => {
  const d = new Date()
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`
}

export const todayISO = () => new Date().toISOString().split('T')[0]

// Parse natural language expense input
// Supports: "com trua 55k", "xang 200", "grab 85k"
export const parseExpenseInput = (text) => {
  if (!text.trim()) return null
  const m = text.match(/(.+?)\s+([\d,.]+)(k|tr|trieu|nghin)?/i)
  if (!m) return null

  let val = parseFloat(m[2].replace(/,/g, ''))
  const unit = (m[3] || '').toLowerCase()

  if (unit === 'tr' || unit === 'trieu') {
    // already in millions
  } else if (unit === 'k' || unit === 'nghin') {
    val = val / 1000
  } else {
    // no unit: assume k if < 100, otherwise already k
    val = val < 100 ? val / 1000 : val / 1000
  }

  const note = m[1].trim()
  let category = 'other'
  if (/an|com|bun|pho|cafe|grab food|banh|sua|tra|nuoc|pizza|burger/i.test(note)) category = 'food'
  else if (/xang|grab|taxi|xe|bus|ve|di lai|gofood/i.test(note)) category = 'transport'
  else if (/dien|nuoc|internet|wifi|dien thoai|tien nha|thue/i.test(note)) category = 'bills'
  else if (/thuoc|kham|benh|gym|yoga|spa|suc khoe/i.test(note)) category = 'health'
  else if (/mua|shop|quan|ao|giay|do dung/i.test(note)) category = 'shopping'
  else if (/phim|nha hang|nhau|bia|du lich|choi|game/i.test(note)) category = 'fun'

  return { note, amount: Math.abs(val), category }
}

// Compound interest calculation
export const calcFV = (monthly, ratePerYear, years) => {
  const r = ratePerYear / 100 / 12
  const n = years * 12
  if (r === 0) return monthly * n
  return monthly * ((Math.pow(1 + r, n) - 1) / r)
}

// Monthly payment for loan
export const calcMonthlyPayment = (principal, ratePerYear, years) => {
  const r = ratePerYear / 100 / 12
  const n = years * 12
  if (r === 0) return principal / n
  return principal * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1)
}
