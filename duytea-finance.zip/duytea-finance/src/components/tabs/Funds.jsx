import { useState } from 'react'
import { Card, Bar, SectionLabel } from '../ui'
import { FUND_DEFS } from '../../constants'
import { fmt, pct } from '../../utils'

export default function Funds({ state, setState }) {
  const [addFund, setAddFund] = useState(null)
  const [addAmt, setAddAmt] = useState('')

  const doAdd = (id) => {
    const v = parseFloat(addAmt)
    if (!v || isNaN(v)) return
    setState(prev => ({
      ...prev,
      funds: { ...prev.funds, [id]: (prev.funds[id] || 0) + v },
    }))
    setAddFund(null)
    setAddAmt('')
  }

  const income = state.config.income.duy

  return (
    <div>
      <SectionLabel>Phan bo hang thang (Duy)</SectionLabel>
      {FUND_DEFS.filter(f => !f.shared).map(f => {
        const alloc = state.config.alloc[f.id] || 0
        return (
          <Card key={f.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{f.icon} {f.name}</div>
                <div style={{ fontSize: 11, color: '#9ca3af' }}>{pct(alloc, income)}% thu nhap</div>
              </div>
              <div style={{ fontSize: 18, fontWeight: 800, color: f.color }}>{fmt(alloc)}tr</div>
            </div>
            <Bar p={pct(alloc, income)} color={f.color} />
          </Card>
        )
      })}

      <SectionLabel>Quy chung gia dinh</SectionLabel>
      {FUND_DEFS.filter(f => f.shared).map(f => {
        const curr = state.funds[f.id] || 0
        const target = state.config.targets[f.id] || f.target
        const alloc = state.config.alloc[f.id] || 0
        const p = pct(curr, target)
        const monthsLeft = alloc > 0 ? Math.ceil((target - curr) / alloc) : null

        return (
          <Card key={f.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{f.icon} {f.name}</div>
                <div style={{ fontSize: 11, color: '#9ca3af' }}>Muc tieu: {fmt(target)}tr</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 17, fontWeight: 800, color: f.color }}>{fmt(curr)}tr</div>
                <div style={{ fontSize: 10, color: '#9ca3af' }}>/ {fmt(target)}tr</div>
              </div>
            </div>
            <Bar p={p} color={f.color} h={8} />
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 3, marginBottom: 10 }}>
              {p}% -{' '}
              {curr >= target ? 'Da dat muc tieu!' : `Con ${fmt(target - curr)}tr`}
              {monthsLeft && curr < target ? ` - ~${monthsLeft} thang` : ''}
            </div>

            {addFund === f.id ? (
              <div style={{ display: 'flex', gap: 6 }}>
                <input
                  value={addAmt}
                  onChange={e => setAddAmt(e.target.value)}
                  type="number"
                  placeholder="So tien (tr)"
                  onKeyDown={e => e.key === 'Enter' && doAdd(f.id)}
                  style={{
                    flex: 1, fontSize: 13, padding: '7px 10px',
                    borderRadius: 10, border: '1px solid #e5e7eb', fontFamily: 'inherit',
                  }}
                />
                <button
                  onClick={() => doAdd(f.id)}
                  style={{ padding: '7px 14px', background: f.color, color: '#fff', border: 'none', borderRadius: 10, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}
                >
                  +
                </button>
                <button
                  onClick={() => setAddFund(null)}
                  style={{ padding: '7px 10px', background: '#fff', border: '1px solid #e5e7eb', borderRadius: 10, cursor: 'pointer', fontFamily: 'inherit' }}
                >
                  x
                </button>
              </div>
            ) : (
              <button
                onClick={() => setAddFund(f.id)}
                style={{
                  width: '100%', padding: '7px',
                  background: f.color + '12',
                  border: `1px dashed ${f.color}`,
                  borderRadius: 10, color: f.color,
                  fontWeight: 700, fontSize: 12, cursor: 'pointer', fontFamily: 'inherit',
                }}
              >
                + Nap vao quy
              </button>
            )}
          </Card>
        )
      })}
    </div>
  )
}
