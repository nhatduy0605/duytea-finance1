import { useState } from 'react'
import { Card, Bar, Button, Input } from '../ui'
import { CATEGORIES } from '../../constants'
import { fmt, pct, today, parseExpenseInput } from '../../utils'

export default function Expenses({ state, setState, profile, isAdmin }) {
  const [input, setInput] = useState('')
  const [filterUser, setFilterUser] = useState('all')
  const [view, setView] = useState('list')

  const add = () => {
    const parsed = parseExpenseInput(input)
    if (!parsed) return
    const tx = {
      id: Date.now(),
      user_id: profile?.id,
      user_name: isAdmin ? 'duy' : 'tea',
      ...parsed,
      date: today(),
      fund_id: 'live',
    }
    setState(prev => ({ ...prev, txs: [tx, ...prev.txs] }))
    setInput('')
  }

  const remove = (id) => {
    setState(prev => ({ ...prev, txs: prev.txs.filter(t => t.id !== id) }))
  }

  const visible = state.txs.filter(t => {
    if (!isAdmin) return t.user_name === 'tea'
    if (filterUser === 'all') return true
    return t.user_name === filterUser
  })

  const total = visible.reduce((s, t) => s + Number(t.amount), 0)

  const catTotals = CATEGORIES.map(c => ({
    ...c,
    total: visible.filter(t => t.category === c.id).reduce((s, t) => s + Number(t.amount), 0),
  })).filter(c => c.total > 0).sort((a, b) => b.total - a.total)

  const maxCat = Math.max(...catTotals.map(c => c.total), 1)

  return (
    <div>
      <Card style={{ background: '#eff6ff', borderColor: 'rgba(37,99,235,0.2)' }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#2563eb', marginBottom: 6 }}>NHAP NHANH</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && add()}
            placeholder="com trua 55k, xang 200k..."
            style={{ flex: 1 }}
          />
          <Button onClick={add}>+</Button>
        </div>
        <div style={{ fontSize: 11, color: '#2563eb', opacity: 0.7, marginTop: 5 }}>
          Tu nhan dang danh muc - Enter de them
        </div>
      </Card>

      {isAdmin && (
        <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
          {[['all', 'Tat ca'], ['duy', 'Duy'], ['tea', 'Tea']].map(([v, l]) => (
            <button
              key={v}
              onClick={() => setFilterUser(v)}
              style={{
                flex: 1, fontSize: 12, fontWeight: 700, padding: '7px',
                borderRadius: 10, cursor: 'pointer', fontFamily: 'inherit',
                border: `1.5px solid ${filterUser === v ? '#2563eb' : '#e5e7eb'}`,
                background: filterUser === v ? '#eff6ff' : '#fff',
                color: filterUser === v ? '#2563eb' : '#6b7280',
              }}
            >
              {l}
            </button>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 4, background: '#f3f4f6', borderRadius: 10, padding: 4, marginBottom: 10 }}>
        {[['list', 'Danh sach'], ['summary', 'Tong ket']].map(([v, l]) => (
          <button
            key={v}
            onClick={() => setView(v)}
            style={{
              flex: 1, fontSize: 12, fontWeight: 700, padding: '7px', border: 'none',
              borderRadius: 7, cursor: 'pointer', fontFamily: 'inherit',
              background: view === v ? '#fff' : 'transparent',
              color: view === v ? '#111827' : '#9ca3af',
              boxShadow: view === v ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
            }}
          >
            {l}
          </button>
        ))}
      </div>

      <Card style={{ background: '#fdeaea', borderColor: 'rgba(224,59,59,0.2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 13, color: '#6b7280' }}>Tong chi</span>
        <span style={{ fontSize: 20, fontWeight: 800, color: '#e03b3b' }}>{fmt(total)}tr</span>
      </Card>

      {view === 'list' && (
        <Card>
          {visible.length === 0 && (
            <div style={{ textAlign: 'center', color: '#9ca3af', padding: '20px 0', fontSize: 13 }}>
              Chua co giao dich nao
            </div>
          )}
          {visible.map((t, i) => {
            const cat = CATEGORIES.find(c => c.id === t.category) || CATEGORIES[CATEGORIES.length - 1]
            const uColor = t.user_name === 'duy' ? '#2563eb' : '#ec4899'
            const uName = t.user_name === 'duy' ? 'Duy' : 'Tea'
            return (
              <div
                key={t.id}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0',
                  borderBottom: i < visible.length - 1 ? '1px solid #f3f4f6' : 'none',
                }}
              >
                <div style={{
                  width: 34, height: 34, borderRadius: 9,
                  background: cat.color + '18',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 17, flexShrink: 0,
                }}>
                  {cat.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{t.note}</div>
                  <div style={{ fontSize: 11, color: '#9ca3af', display: 'flex', gap: 6 }}>
                    <span>{t.date}</span>
                    {isAdmin && <span style={{ color: uColor, fontWeight: 700 }}>{uName}</span>}
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#e03b3b' }}>-{fmt(t.amount)}tr</div>
                  <div style={{ fontSize: 10, color: '#9ca3af' }}>{cat.label}</div>
                </div>
                <button
                  onClick={() => remove(t.id)}
                  style={{ background: 'none', border: 'none', color: '#9ca3af', cursor: 'pointer', fontSize: 16, padding: '0 2px' }}
                >
                  x
                </button>
              </div>
            )
          })}
        </Card>
      )}

      {view === 'summary' && (
        <Card>
          {catTotals.map(c => (
            <div key={c.id} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                <span style={{ fontWeight: 600 }}>{c.icon} {c.label}</span>
                <span style={{ fontWeight: 700, color: c.color }}>{fmt(c.total)}tr</span>
              </div>
              <Bar p={pct(c.total, maxCat)} color={c.color} />
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                {pct(c.total, total)}% tong chi
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  )
}
