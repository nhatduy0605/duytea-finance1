import { Bar, Card, SectionLabel, MetricCard } from '../ui'
import { FUND_DEFS } from '../../constants'
import { fmt, pct } from '../../utils'

export default function Home({ state, profile, isAdmin }) {
  const uid = profile?.id || 'duy'
  const myIncome = isAdmin ? state.config.income.duy : state.config.income.tea
  const mySpend = state.txs.filter(t => t.user_id === uid).reduce((s, t) => s + Number(t.amount), 0)
  const totalHH = state.config.income.duy + state.config.income.tea
  const color = isAdmin ? '#2563eb' : '#ec4899'
  const name = profile?.name || (isAdmin ? 'Duy' : 'Tea')

  return (
    <div>
      <Card style={{ background: `linear-gradient(135deg, ${color}18, ${color}08)`, borderColor: `${color}30` }}>
        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 2 }}>Xin chao</div>
        <div style={{ fontSize: 22, fontWeight: 800, color }}>{name}</div>
        <div style={{ fontSize: 12, color: '#6b7280' }}>
          {isAdmin ? 'Admin - Xem toan bo gia dinh' : 'Member - Ca nhan + quy chung'}
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
        <MetricCard
          label="Thu nhap net/thang"
          value={`${fmt(myIncome)}tr`}
          sub="sau thue"
          color="#0fa968"
          bg="#e8f8f0"
          borderColor="rgba(15,169,104,0.2)"
        />
        {isAdmin ? (
          <MetricCard
            label="Tong ho gia dinh"
            value={`${fmt(totalHH)}tr`}
            sub="Duy + Tea"
            color="#2563eb"
            bg="#eff6ff"
            borderColor="rgba(37,99,235,0.2)"
          />
        ) : (
          <MetricCard
            label="Chi tieu thang"
            value={`${fmt(mySpend)}tr`}
            sub={`${pct(mySpend, myIncome)}% thu nhap`}
            color="#e03b3b"
            bg="#fdeaea"
            borderColor="rgba(224,59,59,0.2)"
          />
        )}
      </div>

      <Card>
        <SectionLabel>Quy chung gia dinh</SectionLabel>
        {FUND_DEFS.filter(f => f.shared).map(f => {
          const curr = state.funds[f.id] || 0
          const target = state.config.targets[f.id] || f.target
          const p = pct(curr, target)
          return (
            <div key={f.id} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span style={{ fontWeight: 600 }}>{f.icon} {f.name}</span>
                <span style={{ fontWeight: 700, color: f.color }}>
                  {fmt(curr)}tr / {fmt(target)}tr
                </span>
              </div>
              <Bar p={p} color={f.color} />
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                {p}% - Con {fmt(target - curr)}tr
              </div>
            </div>
          )
        })}
      </Card>

      {isAdmin && (
        <Card>
          <SectionLabel>Chi tieu thang nay</SectionLabel>
          {[
            { name: 'Duy', uid_key: 'duy', color: '#2563eb', income: state.config.income.duy },
            { name: 'Tea', uid_key: 'tea', color: '#ec4899', income: state.config.income.tea },
          ].map(u => {
            const spend = state.txs
              .filter(t => t.user_name === u.uid_key)
              .reduce((s, t) => s + Number(t.amount), 0)
            return (
              <div key={u.uid_key} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span style={{ fontWeight: 600 }}>{u.name}</span>
                  <span style={{ fontWeight: 700, color: u.color }}>
                    {fmt(spend)}tr / {fmt(u.income)}tr
                  </span>
                </div>
                <Bar p={pct(spend, u.income)} color={u.color} />
              </div>
            )
          })}
        </Card>
      )}
    </div>
  )
}
