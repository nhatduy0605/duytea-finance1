import { useState } from 'react'
import { Card, SectionLabel, Bar } from '../ui'
import { FUND_DEFS } from '../../constants'
import { fmt, pct } from '../../utils'
import { signOut } from '../../lib/supabase'

export default function Settings({ state, setState, profile, isAdmin }) {
  const [saved, setSaved] = useState(false)

  const update = (section, key, val) => {
    const v = parseFloat(val)
    if (isNaN(v) || v < 0) return
    setState(prev => ({
      ...prev,
      config: { ...prev.config, [section]: { ...prev.config[section], [key]: v } },
    }))
    setSaved(true)
    setTimeout(() => setSaved(false), 1500)
  }

  const totalAlloc = Object.values(state.config.alloc).reduce((s, v) => s + v, 0)
  const income = state.config.income.duy
  const over = totalAlloc > income

  return (
    <div>
      {saved && (
        <div style={{ background: '#0fa968', color: '#fff', borderRadius: 10, padding: '8px 14px', marginBottom: 12, fontSize: 12, fontWeight: 700, textAlign: 'center' }}>
          Da luu thay doi
        </div>
      )}

      <Card>
        <SectionLabel>Tai khoan</SectionLabel>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: '#f9fafb', borderRadius: 12 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 22,
            background: isAdmin ? '#2563eb' : '#ec4899',
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 800, fontSize: 18,
          }}>
            {profile?.name?.[0] || 'U'}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700 }}>{profile?.name}</div>
            <div style={{ fontSize: 12, color: '#9ca3af' }}>
              {isAdmin ? 'Admin - Quan tri toan bo' : 'Member - Ca nhan + quy chung'}
            </div>
          </div>
          <button
            onClick={signOut}
            style={{ fontSize: 12, color: '#e03b3b', background: '#fdeaea', border: 'none', borderRadius: 8, padding: '6px 12px', cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit' }}
          >
            Dang xuat
          </button>
        </div>
      </Card>

      {isAdmin && (
        <>
          <Card>
            <SectionLabel>Thu nhap net (tr/thang)</SectionLabel>
            {[['duy', 'Duy', '#2563eb'], ['tea', 'Tea', '#ec4899']].map(([id, name, color]) => (
              <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div style={{
                  width: 34, height: 34, borderRadius: 17, background: color, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, flexShrink: 0,
                }}>
                  {name[0]}
                </div>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{name}</span>
                <input
                  type="number"
                  value={state.config.income[id]}
                  step="0.1"
                  onChange={e => update('income', id, e.target.value)}
                  style={{
                    width: 80, fontSize: 14, fontWeight: 700, padding: '6px 10px',
                    borderRadius: 8, border: `1.5px solid ${color}55`,
                    textAlign: 'right', fontFamily: 'inherit', color,
                  }}
                />
                <span style={{ fontSize: 12, color: '#9ca3af' }}>tr</span>
              </div>
            ))}
          </Card>

          <Card>
            <SectionLabel>Phan bo quy hang thang</SectionLabel>
            <div style={{
              display: 'flex', justifyContent: 'space-between', fontSize: 12,
              padding: '8px 12px', borderRadius: 10, marginBottom: 12,
              background: over ? '#fdeaea' : '#e8f8f0',
            }}>
              <span>Tong phan bo / Thu nhap Duy</span>
              <span style={{ fontWeight: 700, color: over ? '#e03b3b' : '#0fa968' }}>
                {fmt(totalAlloc)}tr / {fmt(income)}tr
              </span>
            </div>

            {FUND_DEFS.map(f => {
              const val = state.config.alloc[f.id] || 0
              const p = pct(val, income)
              return (
                <div key={f.id} style={{ marginBottom: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                    <span style={{ fontWeight: 600 }}>{f.icon} {f.name}</span>
                    <span style={{ fontWeight: 700, color: f.color }}>{fmt(val)}tr ({p}%)</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <input
                      type="range" min={0} max={20} step={0.5} value={val}
                      onChange={e => update('alloc', f.id, e.target.value)}
                      style={{ flex: 1, accentColor: f.color }}
                    />
                    <input
                      type="number" value={val} step="0.5"
                      onChange={e => update('alloc', f.id, e.target.value)}
                      style={{
                        width: 65, fontSize: 13, fontWeight: 700, padding: '5px 8px',
                        borderRadius: 8, border: `1.5px solid ${f.color}55`,
                        textAlign: 'right', fontFamily: 'inherit', color: f.color,
                      }}
                    />
                    <span style={{ fontSize: 11, color: '#9ca3af', width: 14 }}>tr</span>
                  </div>
                  <Bar p={p} color={f.color} h={4} />
                </div>
              )
            })}
          </Card>

          <Card>
            <SectionLabel>Muc tieu quy chung (tr)</SectionLabel>
            {FUND_DEFS.filter(f => f.shared).map(f => (
              <div key={f.id} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <span style={{ fontSize: 18 }}>{f.icon}</span>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{f.name}</span>
                <input
                  type="number" value={state.config.targets[f.id] || f.target} step="10"
                  onChange={e => update('targets', f.id, e.target.value)}
                  style={{
                    width: 80, fontSize: 13, fontWeight: 700, padding: '6px 10px',
                    borderRadius: 8, border: `1.5px solid ${f.color}55`,
                    textAlign: 'right', fontFamily: 'inherit', color: f.color,
                  }}
                />
                <span style={{ fontSize: 11, color: '#9ca3af', width: 14 }}>tr</span>
              </div>
            ))}
          </Card>
        </>
      )}

      <Card style={{ background: '#fef3c7', borderColor: 'rgba(217,119,6,0.2)' }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#d97706', marginBottom: 6 }}>Roadmap tiep theo</div>
        <div style={{ fontSize: 12, color: '#6b7280', lineHeight: 1.9 }}>
          <b>V1 (hien tai):</b> Chi tieu + 6 Quy + Phan quyen<br />
          <b>V2:</b> Mo phong lai kep CCQ + Ke hoach mua nha<br />
          <b>V3:</b> Scan sao ke bang AI (Claude Vision)<br />
          <b>V4:</b> Google Sheets sync + PDF bao cao thang
        </div>
      </Card>
    </div>
  )
}
