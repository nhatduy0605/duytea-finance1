import { useState } from 'react'
import { Card, Bar, SectionLabel } from '../ui'
import { CATEGORIES, FUND_DEFS } from '../../constants'
import { fmt, pct } from '../../utils'

export default function Family({ state, isAdmin }) {
  const [teaView, setTeaView] = useState('shared')

  const duySpend = state.txs.filter(t => t.user_name === 'duy').reduce((s, t) => s + Number(t.amount), 0)
  const teaSpend = state.txs.filter(t => t.user_name === 'tea').reduce((s, t) => s + Number(t.amount), 0)

  if (!isAdmin) {
    const mySpend = teaSpend
    const myIncome = state.config.income.tea

    return (
      <div>
        <div style={{ display: 'flex', gap: 4, background: '#f3f4f6', borderRadius: 10, padding: 4, marginBottom: 14 }}>
          {[['shared', 'Quy chung'], ['mine', 'Cua Tea']].map(([v, l]) => (
            <button
              key={v}
              onClick={() => setTeaView(v)}
              style={{
                flex: 1, fontSize: 12, fontWeight: 700, padding: '7px', border: 'none',
                borderRadius: 7, cursor: 'pointer', fontFamily: 'inherit',
                background: teaView === v ? '#fff' : 'transparent',
                color: teaView === v ? '#ec4899' : '#9ca3af',
                boxShadow: teaView === v ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
              }}
            >
              {l}
            </button>
          ))}
        </div>

        {teaView === 'shared' && (
          <div>
            {FUND_DEFS.filter(f => f.shared).map(f => {
              const curr = state.funds[f.id] || 0
              const target = state.config.targets[f.id] || f.target
              const p = pct(curr, target)
              return (
                <Card key={f.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontSize: 14, fontWeight: 700 }}>{f.icon} {f.name}</span>
                    <span style={{ fontWeight: 700, color: f.color }}>{fmt(curr)}tr / {fmt(target)}tr</span>
                  </div>
                  <Bar p={p} color={f.color} />
                  <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>
                    {p}% - Con {fmt(target - curr)}tr
                  </div>
                </Card>
              )
            })}
          </div>
        )}

        {teaView === 'mine' && (
          <div>
            <Card style={{ background: '#fdf2f8', borderColor: 'rgba(236,72,153,0.2)' }}>
              <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 3 }}>Chi tieu cua Tea thang nay</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#ec4899' }}>{fmt(mySpend)}tr</div>
              <div style={{ fontSize: 12, color: '#6b7280' }}>
                {pct(mySpend, myIncome)}% thu nhap - Con lai {fmt(myIncome - mySpend)}tr
              </div>
              <Bar p={pct(mySpend, myIncome)} color="#ec4899" h={8} />
            </Card>
            {CATEGORIES.map(c => {
              const total = state.txs
                .filter(t => t.user_name === 'tea' && t.category === c.id)
                .reduce((s, t) => s + Number(t.amount), 0)
              if (!total) return null
              return (
                <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '8px 0', borderBottom: '1px solid #f3f4f6' }}>
                  <span>{c.icon} {c.label}</span>
                  <span style={{ fontWeight: 700, color: c.color }}>{fmt(total)}tr</span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    )
  }

  const totalHH = state.config.income.duy + state.config.income.tea

  return (
    <div>
      <Card style={{ background: 'linear-gradient(135deg, #eff6ff, #fdf2f8)' }}>
        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 3 }}>Tong thu nhap ho gia dinh</div>
        <div style={{ fontSize: 24, fontWeight: 800 }}>{fmt(totalHH)}tr/thang</div>
        <div style={{ fontSize: 12, color: '#6b7280' }}>
          Duy: {fmt(state.config.income.duy)}tr + Tea: {fmt(state.config.income.tea)}tr
        </div>
      </Card>

      {[
        { name: 'Duy', key: 'duy', spend: duySpend, income: state.config.income.duy, color: '#2563eb' },
        { name: 'Tea', key: 'tea', spend: teaSpend, income: state.config.income.tea, color: '#ec4899' },
      ].map(u => (
        <Card key={u.key}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>{u.name}</div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: u.color }}>{fmt(u.spend)}tr</div>
              <div style={{ fontSize: 10, color: '#9ca3af' }}>{pct(u.spend, u.income)}% thu nhap</div>
            </div>
          </div>
          <Bar p={pct(u.spend, u.income)} color={u.color} />
          <div style={{ marginTop: 8 }}>
            {CATEGORIES.map(c => {
              const t = state.txs
                .filter(x => x.user_name === u.key && x.category === c.id)
                .reduce((s, x) => s + Number(x.amount), 0)
              if (!t) return null
              return (
                <div key={c.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginTop: 4 }}>
                  <span style={{ color: '#6b7280' }}>{c.icon} {c.label}</span>
                  <span style={{ fontWeight: 600, color: c.color }}>{fmt(t)}tr</span>
                </div>
              )
            })}
          </div>
        </Card>
      ))}

      <Card style={{ background: '#e8f8f0', borderColor: 'rgba(15,169,104,0.2)' }}>
        <SectionLabel>Tiet kiem thang nay</SectionLabel>
        {[
          { label: 'Duy', save: state.config.income.duy - duySpend, income: state.config.income.duy, color: '#2563eb' },
          { label: 'Tea', save: state.config.income.tea - teaSpend, income: state.config.income.tea, color: '#ec4899' },
          { label: 'Tong', save: totalHH - duySpend - teaSpend, income: totalHH, color: '#0fa968' },
        ].map(r => (
          <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
            <span style={{ color: '#6b7280' }}>{r.label}</span>
            <span style={{ fontWeight: 700, color: r.save >= 0 ? r.color : '#e03b3b' }}>
              {r.save >= 0 ? '+' : ''}{fmt(r.save)}tr ({pct(Math.abs(r.save), r.income)}%)
            </span>
          </div>
        ))}
      </Card>
    </div>
  )
}
