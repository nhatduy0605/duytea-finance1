// Shared UI components - no Unicode in comments

export const Bar = ({ p, color, h = 6 }) => (
  <div style={{ height: h, background: '#f3f4f6', borderRadius: 99, overflow: 'hidden', marginTop: 6 }}>
    <div style={{ width: `${Math.min(p, 100)}%`, height: '100%', background: color, borderRadius: 99, transition: 'width 0.4s ease' }} />
  </div>
)

export const Card = ({ children, style = {} }) => (
  <div style={{
    background: '#fff',
    border: '1px solid #e5e7eb',
    borderRadius: 14,
    padding: '14px 16px',
    marginBottom: 10,
    ...style,
  }}>
    {children}
  </div>
)

export const SectionLabel = ({ children }) => (
  <div style={{
    fontSize: 11,
    fontWeight: 700,
    color: '#9ca3af',
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    marginBottom: 8,
    marginTop: 6,
  }}>
    {children}
  </div>
)

export const MetricCard = ({ label, value, sub, color, bg, borderColor }) => (
  <div style={{
    background: bg || '#f9fafb',
    border: `1px solid ${borderColor || '#e5e7eb'}`,
    borderRadius: 12,
    padding: '12px 14px',
  }}>
    <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 3 }}>{label}</div>
    <div style={{ fontSize: 18, fontWeight: 800, color: color || '#111827' }}>{value}</div>
    {sub && <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{sub}</div>}
  </div>
)

export const Button = ({ children, onClick, color = '#2563eb', outline = false, style = {} }) => (
  <button
    onClick={onClick}
    style={{
      padding: '9px 16px',
      background: outline ? 'transparent' : color,
      color: outline ? color : '#fff',
      border: `1.5px solid ${color}`,
      borderRadius: 10,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'inherit',
      fontSize: 13,
      ...style,
    }}
  >
    {children}
  </button>
)

export const Input = ({ value, onChange, onKeyDown, placeholder, type = 'text', style = {} }) => (
  <input
    value={value}
    onChange={onChange}
    onKeyDown={onKeyDown}
    placeholder={placeholder}
    type={type}
    style={{
      fontSize: 13,
      padding: '9px 12px',
      borderRadius: 10,
      border: '1px solid #e5e7eb',
      fontFamily: 'inherit',
      width: '100%',
      ...style,
    }}
  />
)

export const Badge = ({ label, color, bg }) => (
  <span style={{
    fontSize: 10,
    fontWeight: 700,
    padding: '2px 8px',
    borderRadius: 99,
    background: bg || '#f3f4f6',
    color: color || '#6b7280',
    letterSpacing: '0.05em',
    textTransform: 'uppercase',
  }}>
    {label}
  </span>
)

export const BottomNav = ({ tabs, active, onSelect, color }) => (
  <div style={{
    position: 'fixed',
    bottom: 0,
    left: '50%',
    transform: 'translateX(-50%)',
    width: '100%',
    maxWidth: 520,
    background: '#fff',
    borderTop: '1px solid #e5e7eb',
    display: 'flex',
    zIndex: 100,
  }}>
    {tabs.map(t => (
      <button
        key={t.id}
        onClick={() => onSelect(t.id)}
        style={{
          flex: 1,
          padding: '10px 4px 8px',
          border: 'none',
          background: 'transparent',
          cursor: 'pointer',
          fontFamily: 'inherit',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <span style={{ fontSize: 18 }}>{t.icon}</span>
        <span style={{ fontSize: 9, fontWeight: 700, color: active === t.id ? color : '#9ca3af' }}>
          {t.label}
        </span>
        {active === t.id && (
          <div style={{ width: 16, height: 2, background: color, borderRadius: 99 }} />
        )}
      </button>
    ))}
  </div>
)
