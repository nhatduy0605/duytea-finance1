import { useState } from 'react'
import { signIn } from '../lib/supabase'

export default function Auth() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error: err } = await signIn(email, password)
    if (err) setError(err.message)
    setLoading(false)
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(135deg, #2563eb18, #ec489918)',
      padding: '20px',
    }}>
      <div style={{ marginBottom: 32, textAlign: 'center' }}>
        <div style={{ fontSize: 48, marginBottom: 8 }}>💰</div>
        <div style={{ fontSize: 26, fontWeight: 800, color: '#111827' }}>DuyTea Finance</div>
        <div style={{ fontSize: 14, color: '#6b7280', marginTop: 4 }}>Quan ly tai chinh gia dinh</div>
      </div>

      <form
        onSubmit={handleLogin}
        style={{
          background: '#fff', borderRadius: 16, padding: '28px 24px',
          width: '100%', maxWidth: 380,
          border: '1px solid #e5e7eb',
          boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
        }}
      >
        <div style={{ marginBottom: 16 }}>
          <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#6b7280', marginBottom: 6 }}>
            EMAIL
          </label>
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="email@gmail.com"
            required
            style={{
              width: '100%', fontSize: 14, padding: '10px 14px',
              borderRadius: 10, border: '1px solid #e5e7eb',
              fontFamily: 'inherit', outline: 'none',
            }}
          />
        </div>

        <div style={{ marginBottom: 20 }}>
          <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#6b7280', marginBottom: 6 }}>
            MAT KHAU
          </label>
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="••••••••"
            required
            style={{
              width: '100%', fontSize: 14, padding: '10px 14px',
              borderRadius: 10, border: '1px solid #e5e7eb',
              fontFamily: 'inherit', outline: 'none',
            }}
          />
        </div>

        {error && (
          <div style={{ background: '#fdeaea', color: '#e03b3b', borderRadius: 8, padding: '8px 12px', fontSize: 12, marginBottom: 14 }}>
            {error === 'Invalid login credentials' ? 'Email hoac mat khau khong dung' : error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          style={{
            width: '100%', padding: '12px',
            background: loading ? '#93c5fd' : '#2563eb',
            color: '#fff', border: 'none', borderRadius: 10,
            fontWeight: 700, fontSize: 15, cursor: loading ? 'wait' : 'pointer',
            fontFamily: 'inherit',
          }}
        >
          {loading ? 'Dang dang nhap...' : 'Dang nhap'}
        </button>

        <div style={{ fontSize: 12, color: '#9ca3af', textAlign: 'center', marginTop: 16 }}>
          Lien he Duy neu quen mat khau
        </div>
      </form>
    </div>
  )
}
