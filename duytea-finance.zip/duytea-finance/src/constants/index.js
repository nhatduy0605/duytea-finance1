// App-wide constants - no Unicode in variable names, only in string values

export const CATEGORIES = [
  { id: 'food',      label: 'An uong',   icon: '🍜', color: '#d97706' },
  { id: 'transport', label: 'Di lai',    icon: '🚗', color: '#2563eb' },
  { id: 'bills',     label: 'Hoa don',  icon: '🏠', color: '#6b7280' },
  { id: 'health',    label: 'Suc khoe', icon: '🏥', color: '#0fa968' },
  { id: 'shopping',  label: 'Mua sam',  icon: '🛍️', color: '#7c3aed' },
  { id: 'fun',       label: 'Vui choi', icon: '🎉', color: '#e03b3b' },
  { id: 'other',     label: 'Khac',     icon: '📦', color: '#9ca3af' },
]

export const FUND_DEFS = [
  { id: 'live',      name: 'Sinh hoat', icon: '🏠', color: '#6b7280', shared: false },
  { id: 'debt',      name: 'Tra no',    icon: '💳', color: '#e03b3b', shared: false },
  { id: 'invest',    name: 'Dau tu',    icon: '📈', color: '#0fa968', shared: false },
  { id: 'emergency', name: 'Khan cap',  icon: '🛡️', color: '#d97706', shared: true, target: 40 },
  { id: 'house',     name: 'Mua nha',   icon: '🏡', color: '#2563eb', shared: true, target: 750 },
  { id: 'child',     name: 'Con cai',   icon: '👶', color: '#ec4899', shared: true, target: 70 },
]

export const NAV_TABS = [
  { id: 'home',     label: 'Tong quan', icon: '🏠' },
  { id: 'expense',  label: 'Chi tieu',  icon: '💸' },
  { id: 'funds',    label: 'Quy',       icon: '💰' },
  { id: 'family',   label: 'Gia dinh',  icon: '👥' },
  { id: 'settings', label: 'Cai dat',   icon: '⚙️' },
]

export const DEFAULT_CONFIG = {
  income:  { duy: 38.2, tea: 14.7 },
  alloc:   { live: 13.5, debt: 10, invest: 4.5, emergency: 5, house: 2, child: 2.2 },
  targets: { emergency: 40, house: 750, child: 70 },
  budget:  { food: 5, transport: 2, bills: 3, health: 1, shopping: 2, fun: 1.5, other: 0.5 },
}

export const COLORS = {
  blue:   '#2563eb',
  pink:   '#ec4899',
  green:  '#0fa968',
  red:    '#e03b3b',
  amber:  '#d97706',
  purple: '#7c3aed',
  gray:   '#6b7280',
  ink:    '#111827',
  ink2:   '#4b5563',
  ink3:   '#9ca3af',
  border: '#e5e7eb',
  surface:'#f3f4f6',
}
