import { useState, useEffect } from 'react'
import { useAuth } from './hooks/useAuth'
import Auth from './components/Auth'
import { BottomNav } from './components/ui'
import Home from './components/tabs/Home'
import Expenses from './components/tabs/Expenses'
import Funds from './components/tabs/Funds'
import Family from './components/tabs/Family'
import Settings from './components/tabs/Settings'
import { NAV_TABS, DEFAULT_CONFIG } from './constants'
import { saveConfig, getConfig, getFunds } from './lib/supabase'

const INIT_STATE = {
  txs: [],
  funds: { emergency: 12, house: 8, child: 5 },
  config: DEFAULT_CONFIG,
}

export default function App() {
  const { session, profile, loading, isAdmin } = useAuth()
  const [tab, setTab] = useState('home')
  const [state, setStateRaw] = useState(INIT_STATE)
  const [dataLoaded, setDataLoaded] = useState(false)

  // Load data from Supabase when user logs in
  useEffect(() => {
    if (!profile || dataLoaded) return
    const load = async () => {
      try {
        // Load config
        const cfg = await getConfig(profile.id)
        // Load funds
        const fundsData = await getFunds()
        const fundsMap = {}
        fundsData.forEach(f => { fundsMap[f.id] = f.balance / 1000000 })

        setStateRaw(prev => ({
          ...prev,
          funds: { ...prev.funds, ...fundsMap },
          config: {
            income:  cfg.income  || DEFAULT_CONFIG.income,
            alloc:   cfg.alloc   || DEFAULT_CONFIG.alloc,
            targets: cfg.targets || DEFAULT_CONFIG.targets,
            budget:  cfg.budget  || DEFAULT_CONFIG.budget,
          },
        }))
      } catch (e) {
        console.log('Using local defaults:', e.message)
      }
      setDataLoaded(true)
    }
    load()
  }, [profile, dataLoaded])

  const setState = (updater) => {
    setStateRaw(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater
      // Auto-save config to Supabase
      if (profile && next.config !== prev.config) {
        Object.entries(next.config).forEach(([key, value]) => {
          if (JSON.stringify(value) !== JSON.stringify(prev.config[key])) {
            saveConfig(profile.id, key, value).catch(console.error)
          }
        })
      }
      return next
    })
  }

  // Loading screen
  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', background: '#f3f4f6',
      }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>💰</div>
        <div style={{ fontSize: 14, color: '#9ca3af' }}>Dang tai...</div>
      </div>
    )
  }

  // Login screen
  if (!session) return <Auth />

  const color = isAdmin ? '#2563eb' : '#ec4899'
  const name = profile?.name || 'User'

  const tabProps = { state, setState, profile, isAdmin }

  return (
    <div style={{
      fontFamily: '-apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
      maxWidth: 520, margin: '0 auto',
      background: '#f3f4f6', minHeight: '100vh',
      paddingBottom: 70, color: '#111827',
    }}>
      {/* Header */}
      <div style={{
        background: `linear-gradient(135deg, ${color}, ${color}cc)`,
        padding: '14px 16px', position: 'sticky', top: 0, zIndex: 10,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              DuyTea Finance
            </div>
            <div style={{ fontSize: 17, fontWeight: 800, color: '#fff', marginTop: 1 }}>{name}</div>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 20, padding: '4px 10px', fontSize: 11, color: '#fff', fontWeight: 700 }}>
            {isAdmin ? 'Admin' : 'Member'}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '12px 14px' }}>
        {tab === 'home'     && <Home     {...tabProps} />}
        {tab === 'expense'  && <Expenses {...tabProps} />}
        {tab === 'funds'    && <Funds    {...tabProps} />}
        {tab === 'family'   && <Family   {...tabProps} />}
        {tab === 'settings' && <Settings {...tabProps} />}
      </div>

      {/* Bottom nav */}
      <BottomNav tabs={NAV_TABS} active={tab} onSelect={setTab} color={color} />
    </div>
  )
}
