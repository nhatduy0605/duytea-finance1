# DuyTea Finance - Huong dan Deploy

## Tong quan
- Frontend: React + Vite
- Hosting: Vercel (mien phi)
- Database + Auth: Supabase (mien phi)
- URL: duytea-finance.vercel.app

---

## BUOC 1: Tao tai khoan (10 phut)

### 1a. GitHub (neu chua co)
1. Vao github.com -> Sign up
2. Dung email ca nhan, dat mat khau
3. Xac nhan email

### 1b. Supabase
1. Vao supabase.com
2. Click "Start your project"
3. Dang nhap bang GitHub
4. Click "New project"
   - Organization: chon tai khoan ca nhan
   - Project name: duytea-finance
   - Database password: dat mat khau manh (luu lai!)
   - Region: Southeast Asia (Singapore)
5. Cho ~2 phut de tao project

### 1c. Vercel
1. Vao vercel.com
2. Click "Sign Up" -> tiep tuc voi GitHub
3. Done - khong can lam gi them luc nay

---

## BUOC 2: Setup Supabase Database (5 phut)

1. Vao project vua tao tren Supabase
2. Click "SQL Editor" o menu trai
3. Click "New query"
4. Copy toan bo noi dung file `supabase/schema.sql`
5. Paste vao SQL Editor
6. Click "Run" (hoac Ctrl+Enter)
7. Kiem tra: xuat hien thong bao "Success"

### Lay API Keys
1. Vao Settings -> API (menu trai)
2. Copy 2 gia tri:
   - **Project URL**: https://xxxx.supabase.co
   - **anon public**: eyJhbGc... (chuoi dai)
3. Luu vao notepad (dung o buoc 4)

### Tao tai khoan cho Duy (Admin)
1. Vao Authentication -> Users
2. Click "Add user" -> "Create new user"
   - Email: email cua Duy
   - Password: dat mat khau
3. Vao SQL Editor, chay lenh sau (thay YOUR_USER_ID bang ID vua tao):
```sql
UPDATE profiles SET role = 'admin', name = 'Duy', color = '#2563eb'
WHERE id = 'YOUR_USER_ID';
```

### Tao tai khoan cho Tea (Member)
1. Vao Authentication -> Users -> Add user
   - Email: email cua Tea
   - Password: dat mat khau
2. Profile se tu dong la 'member' - khong can lam gi them

---

## BUOC 3: Upload Code len GitHub (5 phut)

### Option A: Dung GitHub Desktop (de hon, khong can biet code)
1. Tai GitHub Desktop: desktop.github.com
2. Cai dat va dang nhap GitHub
3. File -> New Repository
   - Name: duytea-finance
   - Local path: chon thu muc chua code
4. Keo toan bo thu muc code vao
5. Click "Publish repository" (chon Private)

### Option B: Dung GitHub Web (upload truc tiep)
1. Vao github.com -> New repository
2. Ten: duytea-finance, chon Private
3. Upload files: keo toan bo thu muc code vao

---

## BUOC 4: Deploy len Vercel (5 phut)

1. Vao vercel.com -> "Add New Project"
2. Import repository "duytea-finance" tu GitHub
3. Cau hinh:
   - Framework Preset: Vite (tu dong phat hien)
   - Root Directory: de mac dinh
4. **Environment Variables** - QUAN TRONG:
   - Click "Add" -> nhap tung bien:
   ```
   VITE_SUPABASE_URL = https://xxxx.supabase.co  (lay o buoc 2)
   VITE_SUPABASE_ANON_KEY = eyJhbG...             (lay o buoc 2)
   ```
5. Click "Deploy"
6. Cho ~1-2 phut -> App live tai duytea-finance.vercel.app

---

## BUOC 5: Doi ten mien (tuy chon - 2 phut)

1. Tren Vercel, vao project -> Settings -> Domains
2. Add domain: duytea-finance.vercel.app (mac dinh da co)
3. Neu muon: them custom domain rieng

---

## CAP NHAT APP (khi co tinh nang moi)

Khi Duy (hoac Claude) cap nhat code:
1. Upload file moi len GitHub (ghi de file cu)
2. Vercel tu dong deploy lai trong ~1 phut
3. Khong can lam gi them

---

## XU LY LOI THUONG GAP

### "Cannot find module"
-> Chay: npm install

### Trang trang khi mo app
-> Kiem tra Environment Variables trong Vercel co dung khong

### Dang nhap khong duoc
-> Kiem tra email trong Supabase Authentication -> Users

### Loi "RLS policy"
-> Chay lai file schema.sql trong Supabase SQL Editor

---

## HO TRO

Moi van de -> chup anh man hinh -> gui cho Claude phan tich
