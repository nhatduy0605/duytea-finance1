-- ============================================================
-- DuyTea Finance - Supabase Schema
-- Chay file nay trong Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================================
-- PROFILES (lien ket voi Supabase Auth)
-- ============================================================
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  name text not null,
  role text not null default 'member' check (role in ('admin', 'member')),
  color text not null default '#2563eb',
  created_at timestamptz default now()
);

-- ============================================================
-- CONFIG (phan bo quy, thu nhap)
-- ============================================================
create table config (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  key text not null,
  value jsonb not null,
  updated_at timestamptz default now(),
  unique(user_id, key)
);

-- ============================================================
-- TRANSACTIONS (chi tieu)
-- ============================================================
create table transactions (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  amount numeric not null,
  category text not null,
  note text not null default '',
  fund_id text not null default 'live',
  date date not null default current_date,
  created_at timestamptz default now()
);

-- ============================================================
-- FUNDS (so du quy chung)
-- ============================================================
create table funds (
  id text primary key,
  balance numeric not null default 0,
  updated_at timestamptz default now()
);

-- Seed shared funds
insert into funds (id, balance) values
  ('emergency', 12000000),
  ('house', 8000000),
  ('child', 5000000)
on conflict (id) do nothing;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table profiles enable row level security;
alter table config enable row level security;
alter table transactions enable row level security;
alter table funds enable row level security;

-- Profiles: doc profile cua chinh minh
create policy "Users can view own profile"
  on profiles for select using (auth.uid() = id);

create policy "Users can update own profile"
  on profiles for update using (auth.uid() = id);

-- Config: chi chinh sua cua minh, doc duoc cua minh
create policy "Users manage own config"
  on config for all using (auth.uid() = user_id);

-- Transactions:
-- Admin (Duy) doc duoc tat ca
-- Member (Tea) chi doc duoc cua minh
create policy "Admin reads all transactions"
  on transactions for select using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

create policy "Member reads own transactions"
  on transactions for select using (
    auth.uid() = user_id and
    exists (select 1 from profiles where id = auth.uid() and role = 'member')
  );

create policy "Users insert own transactions"
  on transactions for insert with check (auth.uid() = user_id);

create policy "Users delete own transactions"
  on transactions for delete using (auth.uid() = user_id);

-- Funds: tat ca deu xem duoc, chi admin moi sua duoc
create policy "Anyone can view funds"
  on funds for select using (auth.role() = 'authenticated');

create policy "Admin manages funds"
  on funds for all using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- ============================================================
-- FUNCTION: Auto-create profile khi user dang ky
-- ============================================================
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, name, role, color)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', 'User'),
    coalesce(new.raw_user_meta_data->>'role', 'member'),
    coalesce(new.raw_user_meta_data->>'color', '#2563eb')
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ============================================================
-- DONE! Kiem tra bang cach chay:
-- select * from profiles;
-- select * from funds;
-- ============================================================
